# RNA snakemake rules

This repository contains rules for running common RNA-seq commands. 
